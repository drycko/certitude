<?php

namespace App\Http\Controllers\Tenant\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\SendsPasswordResetEmails;

class ForgotPasswordController extends Controller
{
    /*
    |--------------------------------------------------------------------------
    | Password Reset Controller
    |--------------------------------------------------------------------------
    |
    | This controller is responsible for handling password reset emails and
    | includes a trait which assists in sending these notifications from
    | your application to your users. Feel free to explore this trait.
    |
    */

    use SendsPasswordResetEmails;
}


// namespace App\Http\Controllers\Auth;

// use App\Http\Controllers\Controller;
// use Illuminate\Foundation\Auth\SendsPasswordResetEmails;
// use App\Traits\LogsUserActivity;
// use App\Services\NotificationService;
// use Illuminate\Http\Request;
// use App\Models\User;

// class ForgotPasswordController extends Controller
// {
//     use SendsPasswordResetEmails {
//         sendResetLinkEmail as traitSendResetLinkEmail;
//     }
//     use LogsUserActivity;

//     protected NotificationService $notificationService;

//     public function __construct(NotificationService $notificationService)
//     {
//         $this->notificationService = $notificationService;
//     }

//     public function sendResetLinkEmail(Request $request)
//     {
//         try {
//             // Validate email input
//             $request->validate(['email' => 'required|email']);

//             $context = [
//                 'email' => $request->input('email'),
//                 'ip' => $request->ip(),
//                 'user_agent' => $request->header('User-Agent'),
//             ];

//             // Find user (for logging the reset link)
//             $user = User::where('email', $request->input('email'))->first();

//             if ($user) {
//                 // Generate password reset token
//                 $token = app('auth.password.broker')->createToken($user);

//                 // Build the reset URL (same as in the email)
//                 $resetLink = url(route('password.reset', [
//                     'token' => $token,
//                     'email' => $user->email,
//                 ], false));

//                 $context['reset_link'] = $resetLink;
//             }

//             // Log the reset link and context (always logs, even in production)
//             $this->notificationService->logEmail('info', 'password_reset_notification_sent', $context);

//             // Send the reset email as normal by calling the aliased trait method
//             return $this->traitSendResetLinkEmail($request);
//             // Why am I getting this error: Please wait before retrying.? even when it is my first time to submit the form? 

//         } catch (\Exception $e) {
//             // Log the exception with context
//             \Log::error('Error sending password reset email', [
//                 'email' => $request->input('email'),
//                 'error' => $e->getMessage(),
//             ]);
//             // Show a generic error message to the user
//             return back()->withErrors(['email' => 'Failed to send reset email. Please try again later.']);
//         }
//     }
// }