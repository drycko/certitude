<?php

namespace App\Http\Controllers\Tenant\Auth;

use App\Http\Controllers\Controller;
use Illuminate\Foundation\Auth\AuthenticatesUsers;
use App\Traits\LogsUserActivity;

class LoginController extends Controller
{
    use AuthenticatesUsers, LogsUserActivity;

    protected $redirectTo = '/home';

    public function __construct()
    {
        $this->middleware('guest')->except('logout');
        $this->middleware('auth')->only('logout');
    }

    /**
     * Get the needed authorization credentials from the request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return array
     */
    protected function credentials(\Illuminate\Http\Request $request)
    {
        return array_merge($request->only($this->username(), 'password'), ['is_active' => 1]);
    }

    /**
     * Get the failed login response instance.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Symfony\Component\HttpFoundation\Response
     *
     * @throws \Illuminate\Validation\ValidationException
     */
    protected function sendFailedLoginResponse(\Illuminate\Http\Request $request)
    {
        // Check if user exists but is inactive
        $user = \App\Models\User::where($this->username(), $request->{$this->username()})->first();
        
        if ($user && !$user->is_active) {
            throw \Illuminate\Validation\ValidationException::withMessages([
                $this->username() => ['Your account has been deactivated. Please contact an administrator.'],
            ]);
        }

        throw \Illuminate\Validation\ValidationException::withMessages([
            $this->username() => [trans('auth.failed')],
        ]);
    }

    // Called after successful login
    protected function authenticated(\Illuminate\Http\Request $request, $user)
    {
        $this->logLoginActivity();
    }

    // Called after logout
    protected function loggedOut(\Illuminate\Http\Request $request)
    {
        $this->logLogoutActivity();
    }
}