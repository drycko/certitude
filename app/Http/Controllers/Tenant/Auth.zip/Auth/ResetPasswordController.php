<?php

namespace App\Http\Controllers\Tenant\Auth;

use App\Http\Controllers\Controller;
use App\Services\NotificationService;
use Illuminate\Foundation\Auth\ResetsPasswords;
use App\Traits\LogsUserActivity;

class ResetPasswordController extends Controller
{
    use ResetsPasswords {
        resetPassword as traitResetPassword;
    }
    use LogsUserActivity;

    protected NotificationService $notificationService;

    public function __construct(NotificationService $notificationService)
    {
        $this->middleware('guest');
        $this->notificationService = $notificationService;
    }

    /**
     * When password is reset, send email notification to user, log activity, update email verification status.
     */
    protected function resetPassword($user, $password)
    {
        // Call the ResetsPasswords trait's logic
        $this->traitResetPassword($user, $password);

        // Additional actions
        $this->notificationService->sendPasswordResetNotification($user);
        if (method_exists($user, 'markEmailAsVerified')) {
            $user->markEmailAsVerified();
        }
        $this->logPasswordResetActivity($user);
    }

    /**
     * Where to redirect users after resetting their password.
     *
     * @var string
     */
    protected $redirectTo = '/home';
}
